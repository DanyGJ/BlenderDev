# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "FbxExporter2_0",
    "author" : "Dan", 
    "description" : "",
    "blender" : (4, 0, 0),
    "version" : (2, 0, 2),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None


defaddsocket = {'sna_obj': None, }


defduplicatelinked = {'sna_selectedobjects': [], 'sna_name': '', 'sna_parentdummy': None, }


defnewasset = {'sna_addnew_selectionlist': [], 'sna_addnew_meshname': '', }
operators = {'sna_selectionlist': [], 'sna_meshname': '', 'sna_emptyobject': None, 'sna_isolateditem': None, 'sna_recoverisolatedview': False, 'sna_emptylist': [], 'sna_childobjectslist': [], }


def sna_mods_389BC(Object):
    Object.data.uv_layers['UVMap'].name = 'UV0'


def sna_newsocket_08559():
    operators['sna_selectionlist'] = []
    if bpy.context.view_layer.objects.active.type == 'EMPTY':
        operators['sna_selectionlist'].append(bpy.context.view_layer.objects.active)
    else:
        bpy.ops.object.select_hierarchy('INVOKE_DEFAULT', direction='PARENT', extend=False)
        operators['sna_selectionlist'].append(bpy.context.view_layer.objects.active)
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.empty_add('INVOKE_DEFAULT', type='ARROWS', location=bpy.data.scenes['General'].cursor.location, scale=(0.009999999776482582, 0.009999999776482582, 0.009999999776482582))
    bpy.context.area.type = prev_context

    defaddsocket['sna_obj'] = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active.name = 'SOCKET_Spline_01'
    operators['sna_selectionlist'].append(defaddsocket['sna_obj'])
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.area.type = prev_context
    for i_55D5C in range(len(operators['sna_selectionlist'])-1,-1,-1):
        operators['sna_selectionlist'][i_55D5C].select_set(state=True, )
        if operators['sna_selectionlist'][i_55D5C].type == 'EMPTY':
            bpy.context.view_layer.objects.active = operators['sna_selectionlist'][i_55D5C]
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.parent_set()
    bpy.context.area.type = prev_context
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.area.type = prev_context

    defaddsocket['sna_obj'].select_set(state=True, )


def sna_duplicatelinkedref_89A7D():
    if bpy.context.view_layer.objects.active.type == 'EMPTY':

        defduplicatelinked['sna_parentdummy'] = bpy.context.view_layer.objects.active
        bpy.ops.object.select_hierarchy(direction='CHILD', extend=True)
    else:
        bpy.ops.object.select_hierarchy(direction='PARENT', extend=False)

        defduplicatelinked['sna_parentdummy'] = bpy.context.view_layer.objects.active
        bpy.ops.object.select_hierarchy(direction='CHILD', extend=True)

    defduplicatelinked['sna_name'] = 'REF_' + defduplicatelinked['sna_parentdummy'].name
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.duplicate_move_linked()
    bpy.context.area.type = prev_context
    bpy.ops.object.select_hierarchy(direction='PARENT', extend=True)
    bpy.context.view_layer.objects.active.name = defduplicatelinked['sna_name']
    if bpy.context.view_layer.objects.active.type == 'EMPTY':
        bpy.ops.object.select_hierarchy(direction='CHILD', extend=False)
    else:
        bpy.ops.object.select_hierarchy(direction='PARENT', extend=False)
        bpy.ops.object.select_hierarchy(direction='CHILD', extend=False)
    # Define the color you want to assign (RGB values should be between 0 and 1)
    color_value = (0.05, 0.5, 0.46, 1)  # Example color: Red (R=0.8, G=0.2, B=0.2, Alpha=1)
    # Check if the material "Instance" already exists
    mat = bpy.data.materials.get("Instance")
    # If the material doesn't exist, create a new one
    if mat is None:
        mat = bpy.data.materials.new(name="Instance")
        mat.use_nodes = True
        bsdf = mat.node_tree.nodes.get("Principled BSDF")
        if bsdf:
            bsdf.inputs['Base Color'].default_value = color_value
    else:
        # Optionally, update the existing material's color
        bsdf = mat.node_tree.nodes.get("Principled BSDF")
        if bsdf:
            bsdf.inputs['Base Color'].default_value = color_value
    # Loop through all selected objects
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            if len(obj.material_slots) == 0:
                obj.data.materials.append(None)
            obj.material_slots[0].link = 'OBJECT'
            obj.material_slots[0].material = mat
            # Assign the existing "Instance" material to the object
            #obj.data.materials.append(mat)
    # Update the viewport to reflect changes
    bpy.context.view_layer.update()
    bpy.ops.object.select_hierarchy(direction='PARENT', extend=True)


def sna_exportfbx_8759E():
    operators['sna_selectionlist'] = []
    operators['sna_emptylist'] = []
    operators['sna_childobjectslist'] = []
    for i_669D0 in range(len(bpy.context.view_layer.objects.selected)):
        if bpy.context.view_layer.objects.selected[i_669D0].type == 'EMPTY':
            operators['sna_emptylist'].append(bpy.context.view_layer.objects.selected[i_669D0])
        else:
            operators['sna_childobjectslist'].append(bpy.context.view_layer.objects.selected[i_669D0])
        operators['sna_selectionlist'].append(bpy.context.view_layer.objects.selected[i_669D0])
    LocalActive = None
    LocalActive = False
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
           view_3d = area.spaces.active
    if view_3d.local_view:
       print("Local view active")
       LocalActive = True
    else:
       print("Local view not active")
       LocalActive = False
    if ((len(operators['sna_childobjectslist']) == 1) and LocalActive):
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.view3d.localview(frame_selected=False)
        bpy.context.area.type = prev_context
        operators['sna_isolateditem'] = bpy.context.view_layer.objects.active
    operators['sna_recoverisolatedview'] = ((len(operators['sna_childobjectslist']) == 1) and LocalActive)
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.area.type = prev_context
    for i_6B95F in range(len(operators['sna_childobjectslist'])):
        if operators['sna_childobjectslist'][i_6B95F].type == 'MESH':
            operators['sna_emptylist'].append(operators['sna_childobjectslist'][i_6B95F].parent)
    for i_5F511 in range(len(operators['sna_emptylist'])):
        operators['sna_emptyobject'] = operators['sna_emptylist'][i_5F511]
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.object.select_hierarchy(direction='CHILD', extend=False)
        bpy.context.area.type = prev_context
        for i_3B058 in range(len(bpy.context.view_layer.objects.selected)):
            sna_mods_389BC(bpy.context.view_layer.objects.selected[i_3B058])
        operators['sna_emptylist'][i_5F511].select_set(state=True, )
        bpy.context.scene.sna_locationworld = operators['sna_emptylist'][i_5F511].location
        bpy.context.scene.sna_rotationworld = operators['sna_emptylist'][i_5F511].delta_rotation_euler
        operators['sna_emptylist'][i_5F511].location = (0.0, 0.0, 0.0)
        operators['sna_emptylist'][i_5F511].delta_rotation_euler = (0.0, 0.0, 0.0)
        bpy.ops.object.select_more('INVOKE_DEFAULT', )
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.export_scene.fbx(filepath=bpy.context.scene.sna_path + '\\' + 'SM_' + operators['sna_emptyobject'].name + '.fbx', use_selection=True, apply_unit_scale=True, mesh_smooth_type=bpy.context.scene.sna_prefs_meshsmooth, use_triangles=True, axis_forward='Y', axis_up='Z')
        bpy.context.area.type = prev_context
        operators['sna_emptyobject'].location = bpy.context.scene.sna_locationworld
        operators['sna_emptyobject'].delta_rotation_euler = bpy.context.scene.sna_rotationworld
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.area.type = prev_context
        if operators['sna_recoverisolatedview']:
            operators['sna_isolateditem'].select_set(state=True, )
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.view3d.localview(frame_selected=False)
            bpy.context.area.type = prev_context


def sna_newassetf_A6196():
    operators['sna_selectionlist'] = []
    for i_2BB84 in range(len(bpy.context.view_layer.objects.selected)):
        if bpy.context.view_layer.objects.selected[i_2BB84].type == 'MESH':

            defnewasset['sna_addnew_selectionlist'].append(bpy.context.view_layer.objects.selected[i_2BB84])

    defnewasset['sna_addnew_meshname'] = bpy.context.view_layer.objects.active.name
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.empty_add(type='CUBE', radius=0.25, location=bpy.context.view_layer.objects.active.location, scale=(1.0, 1.0, 1.0))
    bpy.context.area.type = prev_context
    bpy.context.view_layer.objects.active.show_name = True
    bpy.context.view_layer.objects.active.name = defnewasset['sna_addnew_meshname'][3:]

    defnewasset['sna_addnew_selectionlist'].append(bpy.context.view_layer.objects.active)
    for i_A1A98 in range(len(defnewasset['sna_addnew_selectionlist'])):

        defnewasset['sna_addnew_selectionlist'][i_A1A98].select_set(state=True, )
    bpy.ops.object.parent_set()
    bpy.ops.object.select_hierarchy('INVOKE_DEFAULT', direction='CHILD')
    for i_26BE7 in range(len(bpy.context.view_layer.objects.selected)):
        bpy.context.view_layer.objects.active.name = 'Mesh_' + defnewasset['sna_addnew_meshname'][3:]


class SNA_MT_953D8(bpy.types.Menu):
    bl_idname = "SNA_MT_953D8"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        box_F63DB = layout.box()
        box_F63DB.alert = False
        box_F63DB.enabled = True
        box_F63DB.active = True
        box_F63DB.use_property_split = False
        box_F63DB.use_property_decorate = False
        box_F63DB.alignment = 'Expand'.upper()
        box_F63DB.scale_x = 1.0
        box_F63DB.scale_y = 1.0
        if not True: box_F63DB.operator_context = "EXEC_DEFAULT"
        box_F63DB.prop(bpy.context.scene, 'sna_path', text='', icon_value=0, emboss=True, expand=False)
        row_9F27C = box_F63DB.row(heading='', align=True)
        row_9F27C.alert = False
        row_9F27C.enabled = True
        row_9F27C.active = True
        row_9F27C.use_property_split = False
        row_9F27C.use_property_decorate = False
        row_9F27C.scale_x = 1.0
        row_9F27C.scale_y = 1.0
        row_9F27C.alignment = 'Expand'.upper()
        row_9F27C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_9F27C.operator('sna.newasset_f2b74', text='New', icon_value=9, emboss=True, depress=False)
        op = row_9F27C.operator('sna.duplicatelinkedref_c8c66', text='Create Ref', icon_value=20, emboss=True, depress=False)
        op = row_9F27C.operator('sna.newsocket_68fbd', text='Sockets', icon_value=234, emboss=True, depress=False)
        op = layout.operator('sna.exportf_00ec6', text='', icon_value=28, emboss=True, depress=False)


class SNA_AddonPreferences_932D6(bpy.types.AddonPreferences):
    bl_idname = 'fbxexporter2_0'

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout.label(text='Export Settings', icon_value=0)
            layout.prop(bpy.context.scene, 'sna_prefs_meshsmooth', text='Mesh Smooth', icon_value=0, emboss=True)


class SNA_OT_Exportf_00Ec6(bpy.types.Operator):
    bl_idname = "sna.exportf_00ec6"
    bl_label = "ExportF"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_exportfbx_8759E()
        self.report({'INFO'}, message='Exported !')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Newasset_F2B74(bpy.types.Operator):
    bl_idname = "sna.newasset_f2b74"
    bl_label = "NewAsset"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_newassetf_A6196()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Duplicatelinkedref_C8C66(bpy.types.Operator):
    bl_idname = "sna.duplicatelinkedref_c8c66"
    bl_label = "DuplicateLinkedRef"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_duplicatelinkedref_89A7D()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Newsocket_68Fbd(bpy.types.Operator):
    bl_idname = "sna.newsocket_68fbd"
    bl_label = "NewSocket"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_newsocket_08559()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_path = bpy.props.StringProperty(name='Path', description='', default='Paste path here...', subtype='FILE_PATH', maxlen=0)
    bpy.types.Scene.sna_locationworld = bpy.props.FloatVectorProperty(name='LocationWorld', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Scene.sna_rotationworld = bpy.props.FloatVectorProperty(name='RotationWorld', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Scene.sna_prefs_meshsmooth = bpy.props.EnumProperty(name='Prefs_MeshSmooth', description='', items=[('OFF', 'OFF', '', 0, 0), ('FACE', 'FACE', '', 0, 1), ('EDGE', 'EDGE', '', 0, 2)])
    bpy.utils.register_class(SNA_MT_953D8)
    bpy.utils.register_class(SNA_AddonPreferences_932D6)
    bpy.utils.register_class(SNA_OT_Exportf_00Ec6)
    bpy.utils.register_class(SNA_OT_Newasset_F2B74)
    bpy.utils.register_class(SNA_OT_Duplicatelinkedref_C8C66)
    bpy.utils.register_class(SNA_OT_Newsocket_68Fbd)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'MIDDLEMOUSE', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    kmi.properties.name = 'SNA_MT_953D8'
    addon_keymaps['63123'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_prefs_meshsmooth
    del bpy.types.Scene.sna_rotationworld
    del bpy.types.Scene.sna_locationworld
    del bpy.types.Scene.sna_path
    bpy.utils.unregister_class(SNA_MT_953D8)
    bpy.utils.unregister_class(SNA_AddonPreferences_932D6)
    bpy.utils.unregister_class(SNA_OT_Exportf_00Ec6)
    bpy.utils.unregister_class(SNA_OT_Newasset_F2B74)
    bpy.utils.unregister_class(SNA_OT_Duplicatelinkedref_C8C66)
    bpy.utils.unregister_class(SNA_OT_Newsocket_68Fbd)
